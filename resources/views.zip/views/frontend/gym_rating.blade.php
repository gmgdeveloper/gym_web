@include('frontend.layouts.gym_rating_header')

<div class="PageWrapper__StyledPageWrapper-sc-3p8f0h-0 lcpsHk RateSchool__StyledAddRatingSchoolPage-sc-1cq0cnj-0 HLiKN">

    <form role="form" class="RateSchool__StyledAddRatingSchoolForm-sc-1cq0cnj-1 hafHAo">
        <div
            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf FormController__StyledFormErrors-sc-17e9grp-0 jHYIoJ">
            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Reputation<span>*</span>
                </div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="reputation"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Reputation</label><input
                                    type="range" name="reputation" id="reputation" value="0" aria-valuemin="0"
                                    aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Location<span>*</span>
                </div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="location"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Location</label><input
                                    type="range" name="location" id="location" value="0" aria-valuemin="0"
                                    aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">
                    Opportunities<span>*</span></div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="opportunities"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Opportunities</label><input
                                    type="range" name="opportunities" id="opportunities" value="0"
                                    aria-valuemin="0" aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Facilities and common
                    areas<span>*</span></div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="facilities"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Facilities
                                    and common areas</label><input type="range" name="facilities" id="facilities"
                                    value="0" aria-valuemin="0" aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Internet<span>*</span>
                </div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="internet"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Internet</label><input
                                    type="range" name="internet" id="internet" value="0" aria-valuemin="0"
                                    aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Food<span>*</span></div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="food"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Food</label><input
                                    type="range" name="food" id="food" value="0" aria-valuemin="0"
                                    aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Clubs<span>*</span>
                </div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="clubs"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Clubs</label><input
                                    type="range" name="clubs" id="clubs" value="0" aria-valuemin="0"
                                    aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Social<span>*</span>
                </div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="social"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Social</label><input
                                    type="range" name="social" id="social" value="0" aria-valuemin="0"
                                    aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Happiness<span>*</span>
                </div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="happiness"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Happiness</label><input
                                    type="range" name="happiness" id="happiness" value="0" aria-valuemin="0"
                                    aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Safety<span>*</span>
                </div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="RatingSlider__StyledRatingSlider-qmpn39-0 cUTwSH">
                        <div
                            class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                            <div
                                class="InputWrapper__StyledTextFieldWrapper-sc-1dxdzcl-0 hDuiTy RatingSlider__HiddenFormSlider-qmpn39-2 jCArVA">
                                <label for="safety"
                                    class="InputWrapper__StaticLabel-sc-1dxdzcl-2 jAbYuF">Safety</label><input
                                    type="range" name="safety" id="safety" value="0" aria-valuemin="0"
                                    aria-valuemax="5" />
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                        <div class="RatingSlider__SliderBoxContainer-qmpn39-1 ihdjqt">
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 icOrwZ"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 fAgwqL"></div>
                            <div type="QUALITY" aria-selected="false" data-testid="SliderBox"
                                class="RatingSliderBox__StyledRatingSliderBox-skwa8i-0 izVfvf"></div>
                        </div>
                        <div class="RatingSliderStatus__SliderStatusContainer-sc-1yt2y2p-0 eXbWmE">
                            <div order="1" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 ogdTl">1 -
                                Awful</div>
                            <div order="2" width="278px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bbGXHf">
                            </div>
                            <div order="3" width="113px"
                                class="RatingSliderStatus__StyledSliderStatus-sc-1yt2y2p-1 bTRLUV">5 -
                                Awesome</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardTitle-sc-16ra1la-2 bNqnap">Write a
                    Review<span></span></div>
                <div class="FormCard__StyledFormCardSubheader-sc-16ra1la-3 kocErm">Discuss your
                    personal experience on this Gym. What’s great about it? What could use
                    improvement?</div>
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div>
                        <div class="InfoBoxGuidelines__StyledInfoBoxContainer-sc-1m5okec-0 ktRyxZ">
                            <div class="InfoBoxGuidelines__StyledInfoBoxTrigger-sc-1m5okec-1 gSZISy">
                                <div class="InfoBoxGuidelines__StyledInfoBoxHeader-sc-1m5okec-2 ckuecy">
                                    <img alt="" src="/static/media/alert.9c5c6685.svg" />
                                    <h2 class="InfoBoxGuidelines__StyledInfoBoxTitle-sc-1m5okec-3 iflaUE">
                                        Guidelines</h2>
                                </div><img alt="" src="/static/media/caret-up-black.cba128c4.svg" />
                            </div>
                            <div class="InfoBoxGuidelines__StyledInfoBox-sc-1m5okec-4 exWlGN">
                                <ol class="InfoBoxGuidelines__StyledInfoBoxList-sc-1m5okec-5 bXOTWo">
                                    <li>Your rating could be removed if you use profanity or derogatory
                                        terms.</li>
                                    <li>Refer to the rating categories to help you better elaborate your
                                        comments.</li>
                                    <li>Don’t forget to proof read!</li>
                                </ol><a theme="[object Object]" target="_blank"
                                    class="InfoBoxGuidelines__StyledLegalLink-sc-1m5okec-6 KbYAj"
                                    href="/guidelines">View all guidelines</a>
                            </div>
                        </div>
                        <div class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf">
                            <div class="FormTextArea__TextAreaContainer-mntwgt-0 fNwBoK">
                                <textarea name="comment" placeholder="What do you want other students to know about this Gym?" rows="9"
                                    class="FormTextArea__StyledTextArea-mntwgt-1 cDiOMj"></textarea><span
                                    class="FormTextArea__LengthCounter-mntwgt-2 fXFjll">0<!-- -->/<!-- -->350</span>
                            </div>
                            <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="FormCard__FormCardContainer-sc-16ra1la-0 kStJld">
            <div data-testid="FORMCARD_TESTID" class="FormCard__StyledFormCard-sc-16ra1la-1 bUsHOg">
                <div class="FormCard__StyledFormCardContent-sc-16ra1la-4 jFzfvl">
                    <div class="SubmitArea__StyledSubmitArea-atru2h-0 hPqoKd">
                        <div class="SubmitArea__StyledLegal-atru2h-1 cnrTNe">By clicking the
                            &quot;Submit&quot; button, I acknowledge that I have read and agreed to
                            the<!-- --> <!-- -->Rate My Professors<!-- --> <a theme="[object Object]" target="_blank"
                                class="SubmitArea__StyledLegalLink-atru2h-2 kOeZHi" href="/guidelines">Site
                                Guidelines</a>,<!-- --> <a theme="[object Object]" target="_blank"
                                class="SubmitArea__StyledLegalLink-atru2h-2 kOeZHi" href="/terms-of-use">Terms of
                                Use</a> and<!-- --> <a theme="[object Object]" target="_blank"
                                class="SubmitArea__StyledLegalLink-atru2h-2 kOeZHi" href="/privacy">Privacy
                                Policy</a>. Submitted data<!-- -->
                            <!-- -->becomes the property of Rate My Professors.
                        </div>
                        <div class="SubmitArea__StyledButtonContainer-atru2h-3 dryOBQ">
                            <div class="FieldWrapper__StyledFieldWrapper-sc-1qtyg1n-0 ebCnIf"><input hidden=""
                                    readonly="" name="recaptcha" value="" /><button
                                    class="SubmitArea__StyledFormRecaptchaButton-atru2h-4 TplOt add-school-rating-btn"
                                    type="submit" disabled="">Submit Rating</button>
                                <div class="FieldWrapper__StyledErrorContainer-sc-1qtyg1n-1 lbqXUp">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
@include('frontend.layouts.gym_rating_footer')
