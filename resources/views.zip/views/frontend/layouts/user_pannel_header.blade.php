<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-react-helmet="true">Rate My Gym</title>
    <link rel="stylesheet" href="userassets/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
</head>

<body>
    <header>
        <div class="header-container">
            <h1 class="logo"><a href="{{route('index')}}">RMG</a></h1>
            <div class="search-bar">
                <div class="search-group">
                    <select class="form-control">
                        <option value="professor">Professor</option>
                        <option value="course">Course</option>
                    </select>
                    <input type="text" placeholder="Professor name">
                </div>
                <div class="search-group">
                    <input type="text" placeholder="Your school">
                </div>
            </div>
            <div class="cta-button">
                <a href="{{route('user_pannel')}}" class="menbtn">HEY, SIRAJ</a>
                <div class="dropdown-content">
                    <a href="#">Profile</a>
                    <a href="#">Account Settings</a>
                    <a href="#">Your Ratings</a>
                    <a href="#">Saved Professors</a>
                    <a href="#">Logout</a>
                </div>
            </div>
        </div>
    </header>