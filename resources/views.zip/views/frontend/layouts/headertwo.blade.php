<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title data-react-helmet="true">Rate My Gym</title>
    <link rel="stylesheet" href="front_assets/css/styletwo.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<body>
    <header>
        <div class="navbar">
            <a href="{{ route('index') }}" class="logo">RMG</a>
            <div class="search-container">
                <select class="school-dropdown">
                    <option value="gym">Gyms</option>
                </select>
                <input type="text" placeholder="Your Gym" style="border-radius: 34px;border: 0px;">
            </div>
            <div class="auth-buttons">
                <button class="login" style="border:0px;">Log In</button>
                <button class="signup">Sign Up</button>
            </div>
        </div>
    </header>