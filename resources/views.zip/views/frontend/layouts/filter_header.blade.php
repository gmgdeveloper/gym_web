<!DOCTYPE html>
<!-- SSR -->
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta name="thumbnail" content="https://www.ratemyprofessors.com/build/thumbnail.svg" />
    <link rel="manifest" href="/build/manifest.json">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="front_assets/css/filter.css">
    <link data-react-helmet="true" rel="icon" href="/favicons/favicon-16.png" sizes />
    <link data-react-helmet="true" rel="icon" href="/favicons/favicon-32.png" sizes="32×32" />
    <link data-react-helmet="true" rel="apple-touch-icon" href="/favicons/favicon-57.png" sizes />
    <link data-react-helmet="true" rel="apple-touch-icon" href="/favicons/favicon-48.png" sizes="48×48" />
    <link data-react-helmet="true" rel="apple-touch-icon" href="/favicons/favicon-72.png" sizes="72×72" />
    <link data-react-helmet="true" rel="apple-touch-icon" href="/favicons/favicon-114.png" sizes="114×114" />
    <link data-react-helmet="true" rel="apple-touch-icon" href="/favicons/favicon-152.png" sizes="152×152" />
    <link data-react-helmet="true" rel="apple-touch-icon-precomposed" href="/favicons/favicon-196.png" sizes />
    <link data-react-helmet="true" rel="canonical" href />
    <title data-react-helmet="true">Rate My Gym</title>
    <meta data-react-helmet="true" property="og:image"
        content="https://www.ratemyprofessors.com/static/media/meta-no-thumbs.16c7cf81.png" />
    <meta data-react-helmet="true" property="og:type" content="website" />
    <meta data-react-helmet="true" name="twitter:card" content="summary_large_image" />
    <meta data-react-helmet="true" name="title" content="John A. Gupton College | Rate My Professors" />
    <meta data-react-helmet="true" name="description"
        content="See what students are saying about John A. Gupton College or leave a rating yourself." />
    <meta data-react-helmet="true" property="og:url" content />
    <meta data-react-helmet="true" property="og:title" content="John A. Gupton College | Rate My Professors" />
    <meta data-react-helmet="true" property="og:description"
        content="See what students are saying about John A. Gupton College or leave a rating yourself." />
    <!-- /21667365449/bounce_x -->
    <div id="div-gpt-ad-1579103811294-0" style="width: 1px; height: 1px;">
        <script>
            googletag.cmd.push(function() {
                googletag.display('div-gpt-ad-1579103811294-0')
            })
        </script>
    </div>
    <style>
        a.rmglogo {
    color: #fff;
    text-decoration: none;
    font-size: 28px;
    padding: 0px 20px 0px 0px;
}
    .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            padding: 10px 20px;
        }

        .logo {
            color: white;
            margin: 0;
        }

        .search-bar {
            display: flex;
            gap: 10px;
        }

        .search-group {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .search-group select,
        .search-group input {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-group select {
            width: 150px;
            background: transparent;
            color: #fff;
            border: 0px;
        }

        .search-group input {
            width: 200px;
        }

        h1.logo a {
            color: #fff;
            text-decoration: none;
            font-size: 25px
        }

        .cta-button {
            position: relative;
            display: inline-block;
            z-index: 91110000 !important;
        }

        .cta-button .menbtn {
            background-color: black;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 20px;
            font-size: 16px;
            text-decoration: none;
        }

        .cta-button button:focus {
            outline: none;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            z-index: 1;
            right: 4px;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;

        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .cta-button:hover .dropdown-content {
            display: block;
        }

        @media (max-width: 768px) {
  .header-container {
    flex-direction: column;
    align-items: center;
    padding: 25px 40px;
  }

  .search-bar {
    flex-direction: column;
    width: 100%;
  }

  .search-bar .search-group {
    width: 100%;
    flex-direction: column;
    padding: 5px 0px;
  }
  .cta-button {
    margin-top: 10px;
}
  a.menbtn{
    background: #fff !important;
    color: #000 !important;
  }

  .search-bar select,
  .search-bar input {
    width: 100%;
    margin-bottom: 10px;
  }

  .profile-container {
    width: 90%;
  }

  .profile-item {
    flex-direction: column;
    align-items: flex-start;
  }

  .profile-item span {
    margin-bottom: 5px;
  }

  .edit-button {
    align-self: stretch;
    text-align: center;
  }
}
    </style>

   
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5HVQ56V" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <div id="root">
        <div class="App__StyledApp-aq7j9t-0 kaBGnN">
            <div class="App__Body-aq7j9t-1 bhyGpW">
                {{-- <div data-testid="StyledHeaderContainer"
                    class="HeaderContainer__StyledHeaderContainer-sc-1eya4wu-0 ducGvC">
                    <div class="Header__HeaderBannerWrapper-sc-1oduwjk-5 enzK">
                        <header role="banner" class="Header__StyledHeader-sc-1oduwjk-1 hNQJBj">
                            <div class="Toastify"></div>
                            <div class="Header__HeaderWrapper-sc-1oduwjk-4 eLUjyu">
                                <div class="Header__StyledDummyElement-sc-1oduwjk-3 kjTgMJ"></div>
                                <div class="HeaderLogo__StyledHeaderLogo-sc-1ehuz2f-2 vWase">
                                    <div class="MobileMenu__MobileMenuWrapper-mf2apz-0 ecMUyP"><button
                                            title="Mobile Menu Button"
                                            class="MobileMenu__MenuButton-mf2apz-2 cdrVhb"></button></div>
                                            <a href="{{route('index')}}" class="rmglogo">RMG</a>
                                            <button
                                        type="button" title="Open search menu"
                                        class="HeaderLogo__SearchIcon-sc-1ehuz2f-0 bFqXne"><img
                                            src="front_assets/images/banner/search-white.7b02d8be.svg" alt="Search Icon" /></button>
                                </div>
                                <div class="HeaderSearch__StyledNewSearch-zmx6ds-0 fiaAxo">
                                    <div class="HeaderSearchMainInput__MainInputWrapper-nft009-0 jBOPiI">
                                        <div><button type="button" role="button" title="Header Type Toggle Button"
                                                class="TeacherSchoolToggleButton__StyledToggleButton-sc-15dbb0q-0 gmfVsA"><span
                                                    class="TeacherSchoolToggleButton__IconWrapper-sc-15dbb0q-4 kljOpt">
                                                    <svg width="18" height="21" viewBox="0 0 18 21"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M9.67889 4.14964C10.078 2.0159 11.9509 0.400024 14.2004 0.400024C14.7527 0.400024 15.2004 0.84774 15.2004 1.40002C15.2004 3.03165 14.3507 4.46501 13.0696 5.28168C15.6839 5.77973 17.6004 8.4971 17.6004 11.8C17.6004 15.7456 14.7573 20.8 11.8004 20.8C10.5678 20.8 9.8655 20.6127 9.3257 20.1809C9.2611 20.1292 9.20071 20.076 9.13303 20.0151C9.12474 20.0078 9.12021 20.0028 9.11718 19.9994L9.11717 19.9994C9.11505 19.9971 9.11367 19.9955 9.11225 19.9946L9.00039 20C8.94042 20 8.91449 19.9963 8.90181 19.9944C8.89392 19.9933 8.89116 19.9929 8.88853 19.9946L8.86775 20.0151C8.80008 20.076 8.73968 20.1292 8.67509 20.1809C8.13528 20.6127 7.43296 20.8 6.20039 20.8C3.24351 20.8 0.400391 15.7456 0.400391 11.8C0.400391 8.14065 2.75289 5.20002 5.80039 5.20002C6.73116 5.20002 7.4215 5.30554 8.00039 5.5141V5.40002C8.00039 5.10508 7.77984 4.85504 7.49683 4.80798L7.40039 4.80002H5.80039C5.24811 4.80002 4.80039 4.35231 4.80039 3.80002C4.80039 3.28719 5.18643 2.86452 5.68377 2.80675L5.80039 2.80002H7.40039C8.37994 2.80002 9.23574 3.3462 9.67889 4.14964ZM8.05318 7.76945C8.35477 7.92025 8.65108 8.00002 9.00039 8.00002C9.3497 8.00002 9.64601 7.92025 9.9476 7.76945L10.4476 7.49445C10.8269 7.30481 11.3159 7.20002 12.2004 7.20002C14.0329 7.20002 15.6004 9.1594 15.6004 11.8C15.6004 14.7878 13.3435 18.8 11.8004 18.8L11.4603 18.795C10.953 18.7785 10.731 18.7223 10.6089 18.6435L10.5253 18.5768L10.4535 18.513C10.0557 18.1632 9.6465 18 9.00039 18C8.35428 18 7.94506 18.1632 7.54724 18.513L7.4257 18.6192C7.2905 18.7273 7.01782 18.8 6.20039 18.8C4.65727 18.8 2.40039 14.7878 2.40039 11.8C2.40039 9.1594 3.96789 7.20002 5.80039 7.20002C6.68489 7.20002 7.17389 7.30481 7.55318 7.49445L8.05318 7.76945Z"
                                                            fill="#ffffff" data-testid="APPLE_PATH_TESTID"></path>
                                                    </svg></span>
                                                <div
                                                    class="TeacherSchoolToggleButton__ToggleButtonText-sc-15dbb0q-2 itGGhm">
                                                    Professors</div><img src="front_assets/images/banner/caret-down.a8eae91f.svg"
                                                    alt="Caret Down" />
                                            </button></div>
                                        <div class="HeaderSearchMainInput__NewSearchWrapper-nft009-1 bLpdSv">
                                            <div class="HeaderSearchInput__TeacherInputWrapper-j8q5if-3 gMZkZH">
                                                <div class="NewSearch__StyledSearchWrapper-pkxwmu-0 eJRnwy">
                                                    <div class="NewSearch__SearchIconWrapper-pkxwmu-2 irUZwm"></div>
                                                    <div
                                                        class="Search__SearchInputContainer-sc-10lefvq-0 koGnqT NewSearch__StyledSearch-pkxwmu-1 fxMegU HeaderSearchInput__TeacherInput-j8q5if-1 eNOUuy">
                                                        <input type="text" value="" aria-label="search"
                                                            placeholder="Professor name"
                                                            class="Search__DebouncedSearchInput-sc-10lefvq-1 fwqnjW" />
                                                    </div>
                                                </div>
                                                <div class="HeaderSearchInput__SelectorInputContainer-j8q5if-5 bIxMQe">
                                                    <div
                                                        class="HeaderSearchInput__SelectorInputWrapper-j8q5if-6 hYCCSW">
                                                        <div class="NewSearch__StyledSearchWrapper-pkxwmu-0 eJRnwy">
                                                            <div class="NewSearch__SearchIconWrapper-pkxwmu-2 irUZwm">
                                                            </div>
                                                            <div
                                                                class="Search__SearchInputContainer-sc-10lefvq-0 koGnqT NewSearch__StyledSearch-pkxwmu-1 fxMegU TeacherSchoolSelectorInput__StyledSchoolSelectorInput-npx66c-0 fnJGVv">
                                                                <input type="text" value=""
                                                                    aria-label="search" placeholder="Your Gym"
                                                                    class="Search__DebouncedSearchInput-sc-10lefvq-1 fwqnjW" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div><button
                                            class="Buttons__TextButton-sc-19xdot-0 HeaderSearchMainInput__InputCancelButton-nft009-2 dZykPc"
                                            type="button">cancel</button>
                                    </div>
                                    <div class="HeaderSearch__SchoolSelectorWrapper-zmx6ds-1 eydgty">
                                        <div class="HeaderSearch__SchoolSelectorWrapperAt-zmx6ds-2 gMXENl">at</div>
                                        <div class="NewSearch__StyledSearchWrapper-pkxwmu-0 eJRnwy">
                                            <div class="NewSearch__SearchIconWrapper-pkxwmu-2 irUZwm"></div>
                                            <div
                                                class="Search__SearchInputContainer-sc-10lefvq-0 koGnqT NewSearch__StyledSearch-pkxwmu-1 dGEpHv TeacherSchoolSelectorInput__StyledSchoolSelectorInput-npx66c-0 fnJGVv">
                                                <input type="text" aria-label="search" placeholder="Your school"
                                                    class="Search__DebouncedSearchInput-sc-10lefvq-1 fwqnjW" /></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="Header__UserMenuWrapper-sc-1oduwjk-2 fHlqte">
                                    <div><button data-testid="AccountButton"
                                            class="UserMenu__MyAccountButton-sc-1rv45rg-4 bgwyxg">Hey, Siraj</button>
                                    </div>
                                </div>
                                <div class="Header__HeaderMobileMenuWrapper-sc-1oduwjk-0 bKRBLv">
                                    <div class="MobileMenu__MobileMenuWrapper-mf2apz-0 ecMUyP"><button
                                            title="Mobile Menu Button"
                                            class="MobileMenu__MenuButton-mf2apz-2 cdrVhb"></button></div>
                                </div>
                            </div>
                        </header>
                    </div>
                </div> --}}
                <header>
                    <div class="header-container">
                        <h1 class="logo"><a href="{{route('index')}}">RMG</a></h1>
                        <div class="search-bar">
                            <div class="search-group">
                                <select class="form-control">
                                    <option value="professor">Professor</option>
                                    <option value="course">Course</option>
                                </select>
                                <input type="text" placeholder="Professor name">
                            </div>
                            <div class="search-group">
                                <input type="text" placeholder="Your school">
                            </div>
                        </div>
                        <div class="cta-button">
                            <a href="{{route('user_pannel')}}" class="menbtn">HEY, SIRAJ</a>
                            <div class="dropdown-content">
                                <a href="#">Profile</a>
                                <a href="#">Account Settings</a>
                                <a href="#">Your Ratings</a>
                                <a href="#">Saved Professors</a>
                                <a href="#">Logout</a>
                            </div>
                        </div>
                    </div>
                </header>
                <div class="__react_component_tooltip tacadf740-c411-4ad3-8624-b0b666537dc7 place-bottom type-dark"
                    id="GLOBAL_TOOLTIP" data-id="tooltip">
                    <style>
                        .tacadf740-c411-4ad3-8624-b0b666537dc7 {
                            color: #fff;
                            background: #222;
                            border: 1px solid transparent;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-top {
                            margin-top: -10px;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-top::before {
                            border-top: 8px solid transparent;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-top::after {
                            border-left: 8px solid transparent;
                            border-right: 8px solid transparent;
                            bottom: -6px;
                            left: 50%;
                            margin-left: -8px;
                            border-top-color: #222;
                            border-top-style: solid;
                            border-top-width: 6px;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-bottom {
                            margin-top: 10px;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-bottom::before {
                            border-bottom: 8px solid transparent;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-bottom::after {
                            border-left: 8px solid transparent;
                            border-right: 8px solid transparent;
                            top: -6px;
                            left: 50%;
                            margin-left: -8px;
                            border-bottom-color: #222;
                            border-bottom-style: solid;
                            border-bottom-width: 6px;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-left {
                            margin-left: -10px;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-left::before {
                            border-left: 8px solid transparent;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-left::after {
                            border-top: 5px solid transparent;
                            border-bottom: 5px solid transparent;
                            right: -6px;
                            top: 50%;
                            margin-top: -4px;
                            border-left-color: #222;
                            border-left-style: solid;
                            border-left-width: 6px;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-right {
                            margin-left: 10px;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-right::before {
                            border-right: 8px solid transparent;
                        }

                        .tacadf740-c411-4ad3-8624-b0b666537dc7.place-right::after {
                            border-top: 5px solid transparent;
                            border-bottom: 5px solid transparent;
                            left: -6px;
                            top: 50%;
                            margin-top: -4px;
                            border-right-color: #222;
                            border-right-style: solid;
                            border-right-width: 6px;
                        }
                    </style>
                </div>
                <header class="StickyHeader__StyledStickyHeaderContainer-sc-19g16mb-0 GQPFJ">
                    <div class="StickyHeader__StyledStickyHeader-sc-19g16mb-1 hyZQlh">
                        <div class="StickyHeader__StyledSecondaryContainerOne-sc-19g16mb-2 cBsYhh">
                            <div class="HeaderDescription__StyledInfoContainer-sc-1lt205f-0 eGhbZq"><span
                                    class="HeaderDescription__StyledCityState-sc-1lt205f-2 cyDJfW">Nashville, TN</span>
                                <div class="HeaderDescription__StyledTitleName-sc-1lt205f-1 eNxccF"><span>John
                                        A. Gupton Gym</span>
                                    <div></div>
                                </div>
                                <div class="HeaderDescription__StyledSubTitlesContainer-sc-1lt205f-4 eulOef">
                                    <div class="SchoolTitles__StyledTitle-sc-3rec2n-0 izsNyq">
                                        <div class="SchoolTitles__LinkContainer-sc-3rec2n-1 fEfAVH"><a
                                                class="SchoolTitles__StyledProfLink-sc-3rec2n-2 kOZsZt"
                                                href="/search/professors/2292?q=*">View all Professors</a></div>
                                    </div>
                                </div>
                            </div>
                            <div class="HeaderRateButton__SchoolActionButtons-rxcxie-3 haeKCm"><a
                                    class="HeaderRateButton__StyledRateSchoolButton-rxcxie-1 gZMNPm"
                                    id="rate-school-btn" href="{{route('contact')}}">Rate this Gym</a><a
                                    class="HeaderRateButton__StyledCompareSchoolButton-rxcxie-2 eJwZuj"
                                    id="compare-school-btn" href="{{route('faq')}}">Compare this Gym</a></div>
                        </div>
                    </div>
                </header>