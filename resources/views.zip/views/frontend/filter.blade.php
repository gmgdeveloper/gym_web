@include('frontend.layouts.filter_header')

                <div class="PageWrapper__StyledPageWrapper-sc-3p8f0h-0 lcpsHk">
                 
                    <div class="SchoolRatings__MainInfoContainer-sc-11x2gz0-0 knYaMp">
                        <div class="OverallRating__OverallRatingContainer-y66epv-0 jryfLJ">
                            <div class="OverallRating__Rating-y66epv-1 fkEGIy">
                                <div class="OverallRating__RatingWrapper-y66epv-2 khkqiH">
                                    <div class="OverallRating__Number-y66epv-3 dXoyqn">2.9</div>
                                    <div class="OverallRating__HelperText-y66epv-4 kMuOOE">Overall Quality</div>
                                </div>
                            </div>
                        </div>
                        <div class="SchoolSummary__SchoolSummaryWrapper-pz83zp-0 crSRKX">
                            <div class="SchoolSummary__SchoolSummaryContainer-pz83zp-1 kYvWmU">
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Opportunities"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Opportunities</div>
                                    <div color="awesomeScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 ffMhzX">
                                        4.3</div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Reputation"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Reputation</div>
                                    <div color="awesomeScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 ffMhzX">
                                        4.0</div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Safety"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Safety</div>
                                    <div color="awesomeScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 ffMhzX">
                                        4.0</div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Happiness"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Happiness</div>
                                    <div color="averageScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 eDqvVi">
                                        3.5</div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Location"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Location</div>
                                    <div color="averageScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 eDqvVi">
                                        3.3</div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Internet"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Internet</div>
                                    <div color="averageScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 eDqvVi">
                                        3.0</div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Facilities"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Facilities</div>
                                    <div color="awfulScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 kOpoGD">2.3
                                    </div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Social"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Social</div>
                                    <div color="awfulScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 kOpoGD">1.8
                                    </div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Food"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Food</div>
                                    <div color="awfulScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 kOpoGD">1.3
                                    </div>
                                </div>
                                <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Clubs"
                                        class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                    <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Clubs</div>
                                    <div color="awfulScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 kOpoGD">1.3
                                    </div>
                                </div>
                            </div>
                            <div class="SchoolSummary__SchoolSummaryMobileContainer-pz83zp-2 iLLSLZ">
                                <div class="SchoolSummary__MobileTitle-pz83zp-3 kThQhj">Highest Rated</div>
                                <hr />
                                <div>
                                    <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                            src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Opportunities"
                                            class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                        <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Opportunities
                                        </div>
                                        <div color="awesomeScore"
                                            class="GradeSquare__ColoredSquare-sc-6d97x2-0 ffMhzX">4.3</div>
                                    </div>
                                </div>
                                <div class="SchoolSummary__MobileTitle-pz83zp-3 kThQhj">Lowest Rated</div>
                                <hr />
                                <div>
                                    <div class="CategoryGrade__CategoryGradeContainer-sc-17vzv7e-0 ivOAGg"><img
                                            src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Clubs"
                                            class="CategoryGrade__CategoryIcon-sc-17vzv7e-2 cVGHd" />
                                        <div class="CategoryGrade__CategoryTitle-sc-17vzv7e-1 XKroK">Clubs</div>
                                        <div color="awfulScore" class="GradeSquare__ColoredSquare-sc-6d97x2-0 kOpoGD">
                                            1.3</div>
                                    </div>
                                </div>
                            </div><button type="button" class="SchoolSummary__ShowAllBtn-pz83zp-4 kfnzjL">
                                <div><span class="SchoolSummary__BtnText-pz83zp-5 Galso">Show all</span><img
                                        src="front_assets/images/banner/opportunities.06eac4c1.svg" alt="Caret Down" /></div>
                            </button>
                        </div>
                    </div>
                    <div id="ad-controller" class="AdController__StyledPlaceholder-sc-1mt9je8-0 Jqjub">
                        <div class="SchoolRatings__VideoPlayerWrapper-sc-11x2gz0-1 bgliqu">
                            <div id="rmp-browsi-video-player" data-type="float"
                                style="postion:static;height:auto;width:auto;max-width:524px;margin-top:16px;margin-bottom:16px;z-index:60000">
                            </div>
                        </div>
                    </div>
                  
                    <div data-ad-target="ratings-list"
                        class="SchoolRatingsContainer__RatingsContainer-sc-1c1ilno-0 iXYxly">
                        <div class="SchoolRatingsContainer__SchoolRatingsCount-sc-1c1ilno-1 jvHnvF">4 Ratings</div>
                        <ul id="schoolRatingsList" class="SchoolRatingsList__ListContainer-sc-1tg2phb-0 jSdWoM">
                            <li>
                                <div class="SchoolRating__SchoolRatingContainer-sb9dsm-0 inMLDw">
                                    <div class="SchoolRating__SchoolRatingBody-sb9dsm-1 JfJQe">
                                        <div class="SchoolRating__OverallRatingContainer-sb9dsm-2 bUrGTi">
                                            <div class="SchoolRating__OverallHeader-sb9dsm-3 epZtNQ">Overall</div>
                                            <div color="averageScore"
                                                class="GradeSquare__ColoredSquare-sc-6d97x2-0 iFoOyg">3.3</div>
                                        </div>
                                        <div class="SchoolRating__MainRatingContainer-sb9dsm-4 rASDq">
                                            <div class="SchoolRating__RatingHeader-sb9dsm-5 yjiuU">
                                                <div
                                                    class="TimeStamp__StyledTimeStamp-sc-9q2r30-0 bXQmMr SchoolRating__StyledTimeStamp-sb9dsm-7 bkDMlg">
                                                    Jun 1st, 2023</div>
                                            </div>
                                            <div class="SchoolRating__RatingComment-sb9dsm-6 eNyCKI">Great college for
                                                mortuary science. Students who act like adults and treat others with
                                                respect will do well. I enjoyed my time here and learned a great deal,
                                                but you do have to put in the effort and do the work. Lots of networking
                                                opportunities. I recommend Gupton but it isn&#x27;t for everyone. Need
                                                to be mature and detail-oriented.</div>
                                            <div>
                                                <div
                                                    class="SchoolRatingSummary__SchoolRatingSummaryContainer-sc-50tcmg-0 cNSIDJ">
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Reputation</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jkfmSh">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Location</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Opportunities</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jkfmSh">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Facilities</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Internet</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kYtEUZ">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Food</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Clubs</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Social</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Happiness</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Safety</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="SchoolRatingFooter__SchoolRatingFooterContainer-sc-1gxs74g-0 hZhpAP">
                                                <div id="thumbs-id" class="Thumbs__ButtonWrapper-sc-19shlav-0 jsOpVQ">
                                                    <div id="thumbs_up"
                                                        class="Thumbs__ThumbContainer-sc-19shlav-1 jLESE">
                                                        <div class="VoteThumb__StyledVoteContainer-p2gtch-1 grVCoH">
                                                            <div class="VoteThumb__HelpfulText-p2gtch-2 biwTxB">Helpful
                                                            </div><img src="front_assets/images/banner/thumbs-up-black.eddae738.svg"
                                                                class="VoteThumb__StyledVoteThumb-p2gtch-0 hZbccg"
                                                                data-tooltip="true" data-tip="Helpful"
                                                                data-for="GLOBAL_TOOLTIP" alt="Thumbs up" />
                                                        </div>
                                                        <div class="Thumbs__HelpTotalNumber-sc-19shlav-2 lihvHt"></div>
                                                    </div>
                                                    <div id="thumbs_down"
                                                        class="Thumbs__ThumbContainer-sc-19shlav-1 jLESE">
                                                        <div class="VoteThumb__StyledVoteContainer-p2gtch-1 grVCoH">
                                                            <div class="VoteThumb__HelpfulText-p2gtch-2 biwTxB"></div>
                                                            <img src="front_assets/images/banner/thumbs-down-black.bd601b36.svg"
                                                                class="VoteThumb__StyledVoteThumb-p2gtch-0 hZbccg"
                                                                data-tooltip="true" data-tip="Not helpful"
                                                                data-for="GLOBAL_TOOLTIP" alt="Thumbs down" />
                                                        </div>
                                                        <div class="Thumbs__HelpTotalNumber-sc-19shlav-2 lihvHt"></div>
                                                    </div>
                                                </div><a class="ReportFlag__StyledReportFlag-sc-1c42epr-0 hjlYuE"
                                                    data-tooltip="true" data-tip="Report this rating"
                                                    data-for="GLOBAL_TOOLTIP" data-testid="reportflag_test_id"
                                                    aria-disabled="false" href="/flag/school-rating/2292/465478">
                                                    <div class="ReportFlag__FlagWrapper-sc-1c42epr-1 kVglhF"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="24"
                                                            height="24" viewBox="0 0 24 24">
                                                            <defs>
                                                                <path id="prefix__a"
                                                                    d="M3.93 10c1.417 0 2.383.276 4.371 1.072 1.762.704 2.546.928 3.629.928 1.189 0 2.094-.165 2.754-.428.095-.039.177-.075.246-.108v-9.86c-.82.253-1.814.396-3 .396-1.417 0-2.383-.276-4.371-1.072C5.797.224 5.013 0 3.93 0 2.741 0 1.836.165 1.176.428A4.094 4.094 0 00.93.536v9.86c.82-.253 1.814-.396 3-.396z">
                                                                </path>
                                                            </defs>
                                                            <g fill="none" fill-rule="evenodd">
                                                                <path fill="#151515" fill-rule="nonzero"
                                                                    d="M3 3a1 1 0 01.293-.707c.22-.22.614-.483 1.21-.721C5.407 1.21 6.564 1 8 1c1.417 0 2.383.276 4.371 1.072C14.133 2.776 14.917 3 16 3c1.189 0 2.094-.165 2.754-.428.341-.137.508-.249.539-.28C19.923 1.663 21 2.11 21 3v12a1 1 0 01-.293.707c-.22.22-.614.483-1.21.721-.903.362-2.06.572-3.497.572-1.417 0-2.383-.276-4.371-1.072C9.867 15.224 9.083 15 8 15c-1.189 0-2.094.165-2.754.428a4.09 4.09 0 00-.247.108L5 22a1 1 0 01-2 0V3zm5 0c-1.189 0-2.094.165-2.754.428A4.094 4.094 0 005 3.536v9.86C5.82 13.143 6.814 13 8 13c1.417 0 2.383.276 4.371 1.072 1.762.704 2.546.928 3.629.928 1.189 0 2.094-.165 2.754-.428.095-.039.177-.075.246-.108v-9.86c-.82.253-1.814.396-3 .396-1.417 0-2.383-.276-4.371-1.072C9.867 3.224 9.083 3 8 3z">
                                                                </path>
                                                                <g transform="translate(4.07 3)">
                                                                    <mask id="prefix__b" fill="#fff">
                                                                        <use xlink:href="#prefix__a"></use>
                                                                    </mask>
                                                                    <use fill="none" fill-rule="nonzero"
                                                                        xlink:href="#prefix__a"></use>
                                                                    <g fill="none" mask="url(#prefix__b)">
                                                                        <path d="M0 0H64V64H0z"
                                                                            transform="translate(-25 -27)"></path>
                                                                    </g>
                                                                </g>
                                                            </g>
                                                        </svg></div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            
                            <li>
                                <div class="SchoolRating__SchoolRatingContainer-sb9dsm-0 inMLDw">
                                    <div class="SchoolRating__SchoolRatingBody-sb9dsm-1 JfJQe">
                                        <div class="SchoolRating__OverallRatingContainer-sb9dsm-2 bUrGTi">
                                            <div class="SchoolRating__OverallHeader-sb9dsm-3 epZtNQ">Overall</div>
                                            <div color="awfulScore"
                                                class="GradeSquare__ColoredSquare-sc-6d97x2-0 evvQvh">2.3</div>
                                        </div>
                                        <div class="SchoolRating__MainRatingContainer-sb9dsm-4 rASDq">
                                            <div class="SchoolRating__RatingHeader-sb9dsm-5 yjiuU">
                                                <div
                                                    class="TimeStamp__StyledTimeStamp-sc-9q2r30-0 bXQmMr SchoolRating__StyledTimeStamp-sb9dsm-7 bkDMlg">
                                                    Oct 21st, 2014</div>
                                            </div>
                                            <div class="SchoolRating__RatingComment-sb9dsm-6 eNyCKI">The school is a
                                                private school for a small field so it makes since for the building to
                                                be small as well. The school has been remodeled and is much more modern
                                                than when I was there. It looks great! Dr. Yates would be proud 3</div>
                                            <div>
                                                <div
                                                    class="SchoolRatingSummary__SchoolRatingSummaryContainer-sc-50tcmg-0 cNSIDJ">
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Reputation</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Location</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kYtEUZ">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Opportunities</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kYtEUZ">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Facilities</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Internet</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kYtEUZ">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Food</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Clubs</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Social</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Happiness</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Safety</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 fRZHHk">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="SchoolRatingFooter__SchoolRatingFooterContainer-sc-1gxs74g-0 hZhpAP">
                                                <div id="thumbs-id" class="Thumbs__ButtonWrapper-sc-19shlav-0 jsOpVQ">
                                                    <div id="thumbs_up"
                                                        class="Thumbs__ThumbContainer-sc-19shlav-1 jLESE">
                                                        <div class="VoteThumb__StyledVoteContainer-p2gtch-1 grVCoH">
                                                            <div class="VoteThumb__HelpfulText-p2gtch-2 biwTxB">Helpful
                                                            </div><img src="front_assets/images/banner/thumbs-up-black.eddae738.svg"
                                                                class="VoteThumb__StyledVoteThumb-p2gtch-0 hZbccg"
                                                                data-tooltip="true" data-tip="Helpful"
                                                                data-for="GLOBAL_TOOLTIP" alt="Thumbs up" />
                                                        </div>
                                                        <div class="Thumbs__HelpTotalNumber-sc-19shlav-2 lihvHt"></div>
                                                    </div>
                                                    <div id="thumbs_down"
                                                        class="Thumbs__ThumbContainer-sc-19shlav-1 jLESE">
                                                        <div class="VoteThumb__StyledVoteContainer-p2gtch-1 grVCoH">
                                                            <div class="VoteThumb__HelpfulText-p2gtch-2 biwTxB"></div>
                                                            <img src="front_assets/images/banner/thumbs-down-black.bd601b36.svg"
                                                                class="VoteThumb__StyledVoteThumb-p2gtch-0 hZbccg"
                                                                data-tooltip="true" data-tip="Not helpful"
                                                                data-for="GLOBAL_TOOLTIP" alt="Thumbs down" />
                                                        </div>
                                                        <div class="Thumbs__HelpTotalNumber-sc-19shlav-2 lihvHt"></div>
                                                    </div>
                                                </div><a class="ReportFlag__StyledReportFlag-sc-1c42epr-0 hjlYuE"
                                                    data-tooltip="true" data-tip="Report this rating"
                                                    data-for="GLOBAL_TOOLTIP" data-testid="reportflag_test_id"
                                                    aria-disabled="false" href="/flag/school-rating/2292/165915">
                                                    <div class="ReportFlag__FlagWrapper-sc-1c42epr-1 kVglhF"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="24"
                                                            height="24" viewBox="0 0 24 24">
                                                            <defs>
                                                                <path id="prefix__a"
                                                                    d="M3.93 10c1.417 0 2.383.276 4.371 1.072 1.762.704 2.546.928 3.629.928 1.189 0 2.094-.165 2.754-.428.095-.039.177-.075.246-.108v-9.86c-.82.253-1.814.396-3 .396-1.417 0-2.383-.276-4.371-1.072C5.797.224 5.013 0 3.93 0 2.741 0 1.836.165 1.176.428A4.094 4.094 0 00.93.536v9.86c.82-.253 1.814-.396 3-.396z">
                                                                </path>
                                                            </defs>
                                                            <g fill="none" fill-rule="evenodd">
                                                                <path fill="#151515" fill-rule="nonzero"
                                                                    d="M3 3a1 1 0 01.293-.707c.22-.22.614-.483 1.21-.721C5.407 1.21 6.564 1 8 1c1.417 0 2.383.276 4.371 1.072C14.133 2.776 14.917 3 16 3c1.189 0 2.094-.165 2.754-.428.341-.137.508-.249.539-.28C19.923 1.663 21 2.11 21 3v12a1 1 0 01-.293.707c-.22.22-.614.483-1.21.721-.903.362-2.06.572-3.497.572-1.417 0-2.383-.276-4.371-1.072C9.867 15.224 9.083 15 8 15c-1.189 0-2.094.165-2.754.428a4.09 4.09 0 00-.247.108L5 22a1 1 0 01-2 0V3zm5 0c-1.189 0-2.094.165-2.754.428A4.094 4.094 0 005 3.536v9.86C5.82 13.143 6.814 13 8 13c1.417 0 2.383.276 4.371 1.072 1.762.704 2.546.928 3.629.928 1.189 0 2.094-.165 2.754-.428.095-.039.177-.075.246-.108v-9.86c-.82.253-1.814.396-3 .396-1.417 0-2.383-.276-4.371-1.072C9.867 3.224 9.083 3 8 3z">
                                                                </path>
                                                                <g transform="translate(4.07 3)">
                                                                    <mask id="prefix__b" fill="#fff">
                                                                        <use xlink:href="#prefix__a"></use>
                                                                    </mask>
                                                                    <use fill="none" fill-rule="nonzero"
                                                                        xlink:href="#prefix__a"></use>
                                                                    <g fill="none" mask="url(#prefix__b)">
                                                                        <path d="M0 0H64V64H0z"
                                                                            transform="translate(-25 -27)"></path>
                                                                    </g>
                                                                </g>
                                                            </g>
                                                        </svg></div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="SchoolRating__SchoolRatingContainer-sb9dsm-0 inMLDw">
                                    <div class="SchoolRating__SchoolRatingBody-sb9dsm-1 JfJQe">
                                        <div class="SchoolRating__OverallRatingContainer-sb9dsm-2 bUrGTi">
                                            <div class="SchoolRating__OverallHeader-sb9dsm-3 epZtNQ">Overall</div>
                                            <div color="awfulScore"
                                                class="GradeSquare__ColoredSquare-sc-6d97x2-0 evvQvh">1.7</div>
                                        </div>
                                        <div class="SchoolRating__MainRatingContainer-sb9dsm-4 rASDq">
                                            <div class="SchoolRating__RatingHeader-sb9dsm-5 yjiuU">
                                                <div
                                                    class="TimeStamp__StyledTimeStamp-sc-9q2r30-0 bXQmMr SchoolRating__StyledTimeStamp-sb9dsm-7 bkDMlg">
                                                    Jul 22nd, 2014</div>
                                            </div>
                                            <div class="SchoolRating__RatingComment-sb9dsm-6 eNyCKI">The school is not
                                                good</div>
                                            <div>
                                                <div
                                                    class="SchoolRatingSummary__SchoolRatingSummaryContainer-sc-50tcmg-0 cNSIDJ">
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Reputation</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Location</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kYtEUZ">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 kAlHtf">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Opportunities</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Facilities</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Internet</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Food</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Clubs</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Social</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Happiness</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Safety</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 fRZHHk">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="SchoolRatingFooter__SchoolRatingFooterContainer-sc-1gxs74g-0 hZhpAP">
                                                <div id="thumbs-id" class="Thumbs__ButtonWrapper-sc-19shlav-0 jsOpVQ">
                                                    <div id="thumbs_up"
                                                        class="Thumbs__ThumbContainer-sc-19shlav-1 jLESE">
                                                        <div class="VoteThumb__StyledVoteContainer-p2gtch-1 grVCoH">
                                                            <div class="VoteThumb__HelpfulText-p2gtch-2 biwTxB">Helpful
                                                            </div><img src="front_assets/images/banner/thumbs-up-black.eddae738.svg"
                                                                class="VoteThumb__StyledVoteThumb-p2gtch-0 hZbccg"
                                                                data-tooltip="true" data-tip="Helpful"
                                                                data-for="GLOBAL_TOOLTIP" alt="Thumbs up" />
                                                        </div>
                                                        <div class="Thumbs__HelpTotalNumber-sc-19shlav-2 lihvHt"></div>
                                                    </div>
                                                    <div id="thumbs_down"
                                                        class="Thumbs__ThumbContainer-sc-19shlav-1 jLESE">
                                                        <div class="VoteThumb__StyledVoteContainer-p2gtch-1 grVCoH">
                                                            <div class="VoteThumb__HelpfulText-p2gtch-2 biwTxB"></div>
                                                            <img src="front_assets/images/banner/thumbs-down-black.bd601b36.svg"
                                                                class="VoteThumb__StyledVoteThumb-p2gtch-0 hZbccg"
                                                                data-tooltip="true" data-tip="Not helpful"
                                                                data-for="GLOBAL_TOOLTIP" alt="Thumbs down" />
                                                        </div>
                                                        <div class="Thumbs__HelpTotalNumber-sc-19shlav-2 lihvHt"></div>
                                                    </div>
                                                </div><a class="ReportFlag__StyledReportFlag-sc-1c42epr-0 hjlYuE"
                                                    data-tooltip="true" data-tip="Report this rating"
                                                    data-for="GLOBAL_TOOLTIP" data-testid="reportflag_test_id"
                                                    aria-disabled="false" href="/flag/school-rating/2292/155416">
                                                    <div class="ReportFlag__FlagWrapper-sc-1c42epr-1 kVglhF"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="24"
                                                            height="24" viewBox="0 0 24 24">
                                                            <defs>
                                                                <path id="prefix__a"
                                                                    d="M3.93 10c1.417 0 2.383.276 4.371 1.072 1.762.704 2.546.928 3.629.928 1.189 0 2.094-.165 2.754-.428.095-.039.177-.075.246-.108v-9.86c-.82.253-1.814.396-3 .396-1.417 0-2.383-.276-4.371-1.072C5.797.224 5.013 0 3.93 0 2.741 0 1.836.165 1.176.428A4.094 4.094 0 00.93.536v9.86c.82-.253 1.814-.396 3-.396z">
                                                                </path>
                                                            </defs>
                                                            <g fill="none" fill-rule="evenodd">
                                                                <path fill="#151515" fill-rule="nonzero"
                                                                    d="M3 3a1 1 0 01.293-.707c.22-.22.614-.483 1.21-.721C5.407 1.21 6.564 1 8 1c1.417 0 2.383.276 4.371 1.072C14.133 2.776 14.917 3 16 3c1.189 0 2.094-.165 2.754-.428.341-.137.508-.249.539-.28C19.923 1.663 21 2.11 21 3v12a1 1 0 01-.293.707c-.22.22-.614.483-1.21.721-.903.362-2.06.572-3.497.572-1.417 0-2.383-.276-4.371-1.072C9.867 15.224 9.083 15 8 15c-1.189 0-2.094.165-2.754.428a4.09 4.09 0 00-.247.108L5 22a1 1 0 01-2 0V3zm5 0c-1.189 0-2.094.165-2.754.428A4.094 4.094 0 005 3.536v9.86C5.82 13.143 6.814 13 8 13c1.417 0 2.383.276 4.371 1.072 1.762.704 2.546.928 3.629.928 1.189 0 2.094-.165 2.754-.428.095-.039.177-.075.246-.108v-9.86c-.82.253-1.814.396-3 .396-1.417 0-2.383-.276-4.371-1.072C9.867 3.224 9.083 3 8 3z">
                                                                </path>
                                                                <g transform="translate(4.07 3)">
                                                                    <mask id="prefix__b" fill="#fff">
                                                                        <use xlink:href="#prefix__a"></use>
                                                                    </mask>
                                                                    <use fill="none" fill-rule="nonzero"
                                                                        xlink:href="#prefix__a"></use>
                                                                    <g fill="none" mask="url(#prefix__b)">
                                                                        <path d="M0 0H64V64H0z"
                                                                            transform="translate(-25 -27)"></path>
                                                                    </g>
                                                                </g>
                                                            </g>
                                                        </svg></div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="SchoolRating__SchoolRatingContainer-sb9dsm-0 inMLDw">
                                    <div class="SchoolRating__SchoolRatingBody-sb9dsm-1 JfJQe">
                                        <div class="SchoolRating__OverallRatingContainer-sb9dsm-2 bUrGTi">
                                            <div class="SchoolRating__OverallHeader-sb9dsm-3 epZtNQ">Overall</div>
                                            <div color="averageScore"
                                                class="GradeSquare__ColoredSquare-sc-6d97x2-0 iFoOyg">3.2</div>
                                        </div>
                                        <div class="SchoolRating__MainRatingContainer-sb9dsm-4 rASDq">
                                            <div class="SchoolRating__RatingHeader-sb9dsm-5 yjiuU">
                                                <div
                                                    class="TimeStamp__StyledTimeStamp-sc-9q2r30-0 bXQmMr SchoolRating__StyledTimeStamp-sb9dsm-7 bkDMlg">
                                                    Apr 6th, 2011</div>
                                            </div>
                                            <div class="SchoolRating__RatingComment-sb9dsm-6 eNyCKI">Not Specified.
                                            </div>
                                            <div>
                                                <div
                                                    class="SchoolRatingSummary__SchoolRatingSummaryContainer-sc-50tcmg-0 cNSIDJ">
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Reputation</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jkfmSh">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Location</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jkfmSh">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Opportunities</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jkfmSh">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Facilities</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Internet</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Food</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Clubs</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Social</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 gMxmfx">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 htGceI">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Happiness</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 ibsre">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 bDGPpv">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jkfmSh">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="DisplaySlider__DisplaySliderContainer-sc-6etfq5-0 bIaaU">
                                                        <div
                                                            class="DisplaySlider__DisplaySliderLabel-sc-6etfq5-1 eamCvq">
                                                            Safety</div>
                                                        <div
                                                            class="DisplaySlider__SliderBoxContainer-sc-6etfq5-2 ePbaHA">
                                                            <div data-testid="slider-box-1"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 fRZHHk">
                                                            </div>
                                                            <div data-testid="slider-box-2"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-3"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-4"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jEhBWA">
                                                            </div>
                                                            <div data-testid="slider-box-5"
                                                                class="DisplaySlider__DisplaySliderBox-sc-6etfq5-3 jYqWUD">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="SchoolRatingFooter__SchoolRatingFooterContainer-sc-1gxs74g-0 hZhpAP">
                                                <div id="thumbs-id"
                                                    class="Thumbs__ButtonWrapper-sc-19shlav-0 jsOpVQ">
                                                    <div id="thumbs_up"
                                                        class="Thumbs__ThumbContainer-sc-19shlav-1 jLESE">
                                                        <div class="VoteThumb__StyledVoteContainer-p2gtch-1 grVCoH">
                                                            <div class="VoteThumb__HelpfulText-p2gtch-2 biwTxB">
                                                                Helpful</div><img
                                                                src="front_assets/images/banner/thumbs-up-black.eddae738.svg"
                                                                class="VoteThumb__StyledVoteThumb-p2gtch-0 hZbccg"
                                                                data-tooltip="true" data-tip="Helpful"
                                                                data-for="GLOBAL_TOOLTIP" alt="Thumbs up" />
                                                        </div>
                                                        <div class="Thumbs__HelpTotalNumber-sc-19shlav-2 lihvHt">
                                                        </div>
                                                    </div>
                                                    <div id="thumbs_down"
                                                        class="Thumbs__ThumbContainer-sc-19shlav-1 jLESE">
                                                        <div class="VoteThumb__StyledVoteContainer-p2gtch-1 grVCoH">
                                                            <div class="VoteThumb__HelpfulText-p2gtch-2 biwTxB"></div>
                                                            <img src="front_assets/images/banner/thumbs-down-black.bd601b36.svg"
                                                                class="VoteThumb__StyledVoteThumb-p2gtch-0 hZbccg"
                                                                data-tooltip="true" data-tip="Not helpful"
                                                                data-for="GLOBAL_TOOLTIP" alt="Thumbs down" />
                                                        </div>
                                                        <div class="Thumbs__HelpTotalNumber-sc-19shlav-2 lihvHt">
                                                        </div>
                                                    </div>
                                                </div><a class="ReportFlag__StyledReportFlag-sc-1c42epr-0 hjlYuE"
                                                    data-tooltip="true" data-tip="Report this rating"
                                                    data-for="GLOBAL_TOOLTIP" data-testid="reportflag_test_id"
                                                    aria-disabled="false" href="/flag/school-rating/2292/40766">
                                                    <div class="ReportFlag__FlagWrapper-sc-1c42epr-1 kVglhF"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="24"
                                                            height="24" viewBox="0 0 24 24">
                                                            <defs>
                                                                <path id="prefix__a"
                                                                    d="M3.93 10c1.417 0 2.383.276 4.371 1.072 1.762.704 2.546.928 3.629.928 1.189 0 2.094-.165 2.754-.428.095-.039.177-.075.246-.108v-9.86c-.82.253-1.814.396-3 .396-1.417 0-2.383-.276-4.371-1.072C5.797.224 5.013 0 3.93 0 2.741 0 1.836.165 1.176.428A4.094 4.094 0 00.93.536v9.86c.82-.253 1.814-.396 3-.396z">
                                                                </path>
                                                            </defs>
                                                            <g fill="none" fill-rule="evenodd">
                                                                <path fill="#151515" fill-rule="nonzero"
                                                                    d="M3 3a1 1 0 01.293-.707c.22-.22.614-.483 1.21-.721C5.407 1.21 6.564 1 8 1c1.417 0 2.383.276 4.371 1.072C14.133 2.776 14.917 3 16 3c1.189 0 2.094-.165 2.754-.428.341-.137.508-.249.539-.28C19.923 1.663 21 2.11 21 3v12a1 1 0 01-.293.707c-.22.22-.614.483-1.21.721-.903.362-2.06.572-3.497.572-1.417 0-2.383-.276-4.371-1.072C9.867 15.224 9.083 15 8 15c-1.189 0-2.094.165-2.754.428a4.09 4.09 0 00-.247.108L5 22a1 1 0 01-2 0V3zm5 0c-1.189 0-2.094.165-2.754.428A4.094 4.094 0 005 3.536v9.86C5.82 13.143 6.814 13 8 13c1.417 0 2.383.276 4.371 1.072 1.762.704 2.546.928 3.629.928 1.189 0 2.094-.165 2.754-.428.095-.039.177-.075.246-.108v-9.86c-.82.253-1.814.396-3 .396-1.417 0-2.383-.276-4.371-1.072C9.867 3.224 9.083 3 8 3z">
                                                                </path>
                                                                <g transform="translate(4.07 3)">
                                                                    <mask id="prefix__b" fill="#fff">
                                                                        <use xlink:href="#prefix__a"></use>
                                                                    </mask>
                                                                    <use fill="none" fill-rule="nonzero"
                                                                        xlink:href="#prefix__a"></use>
                                                                    <g fill="none" mask="url(#prefix__b)">
                                                                        <path d="M0 0H64V64H0z"
                                                                            transform="translate(-25 -27)"></path>
                                                                    </g>
                                                                </g>
                                                            </g>
                                                        </svg></div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            
                        </ul>
                    </div>
                    <div id="ad-controller" class="AdController__StyledPlaceholder-sc-1mt9je8-0 Jqjub">
                        <div id="taboola-below-article-thumbnails"
                            class="TaboolaAd__StyledTaboolaAd-sc-16lajh5-0 fkoCRH" data-testid="test-id-taboola-ad">
                        </div>
                    </div>
                </div>
                
@include('frontend.layouts.filter_footer')
