@include('frontend.layouts.headertwo')

    <main>
        <h1>6 gyms with "aa" in their name</h1>
        <div class="school-list">
            <a class="text-dark text-decoration-none" href="{{route('filter')}}">
            <div class="school-item">
                <div class="rating" style="background-color: #ffeb3b;">3.9</div>
                <div class="school-info">
                    <h2>AA Gym of Architecture - Bedford Square</h2>
                    <p>1 ratings</p>
                </div>
            </div>
        </a>
        <a class="text-dark text-decoration-none" href="{{route('filter')}}">
            <div class="school-item">
                <div class="rating" style="background-color: #b2ff59;">4.8</div>
                <div class="school-info">
                    <h2>AA Gym of Architecture - Hooke Park</h2>
                    <p>1 ratings</p>
                    <span>Dorset, LONDON</span>
                </div>

            </div>
        </a>

            <div class="lastbtn">
                <a href="#" class="btn btn-primary  first_a mb-2">Show More</a>
                <br>
                <span class="first_span mb-2">Don't see the school you're looking <br> for?</span>
                <br>

                <a href="#" class="text-dark mb-2">Add a Gym</a>
            </div>
        </div>
    </main>

    @include('frontend.layouts.footertwo')
