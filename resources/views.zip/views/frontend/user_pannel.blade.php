@include('frontend.layouts.user_pannel_header')

    <main>
        <div class="profile-container">
            <h2>Hey, Siraj</h2>
            <nav>
                <ul>
                    <li class="active" onclick="showSection('profile')">Profile</li>
                    <li onclick="showSection('account-settings')">Account Settings</li>
                    <li onclick="showSection('ratings')">Ratings</li>
                    <li onclick="showSection('saved-professors')">Saved Professors</li>
                </ul>
            </nav>
            <div id="profile" class="content-section active">
                <div class="profile-info">
                    <div class="profile-item">
                        <span class="label">First Name</span>
                        <span>Siraj</span>
                    </div>
                    <div class="profile-item">
                        <span class="label">Last Name</span>
                        <span>Umrani</span>
                    </div>
                    <div class="profile-item">
                        <span class="label">Gym</span>
                        <span>FitZone Fitness Center</span>
                    </div>
                    <div class="profile-item">
                        <span class="label">Favorite Workout</span>
                        <span>Strength Training</span>
                    </div>
                    <div class="profile-item">
                        <span class="label">Weekly Visits</span>
                        <span>4 times</span>
                    </div>
                </div>
            </div>
            
            <div id="account-settings" class="content-section" style="display: none;">
                <div class="upper-inputs">
                    <h3>Account Settings</h3>
                    <button class="edit-button"><i class="fas fa-edit"></i> Edit</button>
                </div>
                <div class="account-item">
                    <span class="label">Email</span>
                    <span class="value">sirajumrani110@gmail.com</span>
                </div>
                <div class="account-item">
                    <span class="label">Password</span>
                    <span class="value">*********</span>
                </div>
            </div>
            <div id="ratings" class="content-section" style="display: none;">
                <h3>Ratings</h3>
                {{-- <div class="rating">
                    <h4>Instructor John Doe</h4>
                    <div class="rating-detail">
                        <span class="label">Class:</span>
                        <span class="value">HIIT Workout</span>
                    </div>
                    <div class="rating-detail">
                        <span class="label">Rating:</span>
                        <span class="value">4.8/5</span>
                    </div>
                    <div class="rating-detail">
                        <span class="label">Comments:</span>
                        <span class="value">Excellent instructor! The HIIT workout is challenging but very effective. John is very motivating and makes sure everyone maintains proper form.</span>
                    </div>
                </div>
                <div class="rating">
                    <h4>Instructor Jane Smith</h4>
                    <div class="rating-detail">
                        <span class="label">Class:</span>
                        <span class="value">Yoga</span>
                    </div>
                    <div class="rating-detail">
                        <span class="label">Rating:</span>
                        <span class="value">4.5/5</span>
                    </div>
                    <div class="rating-detail">
                        <span class="label">Comments:</span>
                        <span class="value">Jane's yoga classes are amazing. She has a calm and soothing demeanor, which makes the sessions very relaxing. Great for all levels.</span>
                    </div>
                </div>
                <div class="rating">
                    <h4>Instructor Mike Johnson</h4>
                    <div class="rating-detail">
                        <span class="label">Class:</span>
                        <span class="value">Strength Training</span>
                    </div>
                    <div class="rating-detail">
                        <span class="label">Rating:</span>
                        <span class="value">4.7/5</span>
                    </div>
                    <div class="rating-detail">
                        <span class="label">Comments:</span>
                        <span class="value">Mike's strength training sessions are top-notch. He focuses on technique and ensures everyone is lifting safely. Highly recommended!</span>
                    </div>
                </div> --}}
                <div class="no-rating">
                    <h4>No Ratings Available</h4>
                    <p>You haven't given any ratings yet. Start rating your instructors to see them here!</p>
                </div>
                
            </div>
            <div id="saved-professors" class="content-section" style="display: none;">
                <h3>Saved Professors</h3>
                <div class="no-rating">
                    <h4>You don’t have any saved professors yet</h4>
                </div>
            </div>
        </div>
    </main>
@include('frontend.layouts.user_pannel_footer')
  